"""
Tools to help with PyUnity development

"""

__version__ = "0.1.0"
__copyright__ = "Copyright 2020-2021 Ray Chen"
__email__ = "tankimarshal2@gmail.com"
__license__ = "MIT License"
__summary__ = "Tools to help with PyUnity development"
__title__ = "pyunity-tools"
__uri__ = "https://github.com/pyunity/pyunity-tools"
